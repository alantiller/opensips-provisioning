<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <span class="text-muted">OpenSIPS Provisioning is licenced under MIT. Build and maintained by Alan Tiller.</span>
    </div>
</footer>